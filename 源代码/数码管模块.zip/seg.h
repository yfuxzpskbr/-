#ifndef _SEG_H
#define _SEG_H
#define PICK P2
#define LED P1
extern unsigned char code led_code[17];
extern int seg_buffer[8];
extern unsigned char code pick_code[];
void display();
void update_seg_buffer(int *key_buffer);

#endif