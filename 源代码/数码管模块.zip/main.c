#include <reg51.h>
#include <stdio.h>

#include "seg.h"

void main(){
	while(1){
		display();  //��ʾ
	}
}


