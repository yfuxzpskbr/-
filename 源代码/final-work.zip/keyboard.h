#ifndef _KEYBOARD_H
#define _KEYBOARD_H
#define INPUT P1
extern int keyValue;
extern int isClick;
extern int password[8];
extern int key_buffer[8];
void keyDown();
bit submit();
void resolve(void (*KeyEvent)(int key));
void update_key_buffer();
void clear_key_buffer();
#endif