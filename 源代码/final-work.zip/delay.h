#ifndef _DELAY_H
#define _DELAY_H

void delay(int t);

#endif
