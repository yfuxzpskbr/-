#include "seg.h"
#include "music.h"
#include "keyboard.h"
#include "delay.h"
int seg_buffer[8]={16,16,16,16,16,16,16,16}; //SEG����ܻ�����
unsigned char code pick_code[]={0x80,0x40,0x20,0x10,0x08,0x04,0x02,0x01}; //�����ѡ��
unsigned char code led_code[17]={
	0x0C0,//"0"
	0x0F9,//"1"
	0x0A4,//"2"
	0x0B0,//"3"
	0x99, //"4"
	0x92, //"5"
	0x82, //"6"
	0x0F8,//"7"
	0x80, //"8"
	0x90, //"9"
	0x88, //"A"(10)
	0x83, //"b"(11)
	0x0C6,//"C"(12)
	0x0A1,//"d"(13)
	0x86, //"E"(14)
	0x8E, //"F"(15)
	0x0BF,//"-" 
};

/**
	Ӳ���޹غ�������ʾ_8_code���������ֵ
*/
void display(){
	int i;
	for(i=0;i<8;i++){
			PICK = pick_code[i];
			LED = led_code[seg_buffer[i]];
			delay(3);
	}
}

void update_seg_buffer(int *other_buffer){
	int i;
	for(i=7;i>=0;i--){
		seg_buffer[i]=key_buffer[i];
	}
} 