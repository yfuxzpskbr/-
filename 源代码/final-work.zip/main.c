#include "combine.h"

void main(){
	 start();
}


