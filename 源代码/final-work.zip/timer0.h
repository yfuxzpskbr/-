#ifndef _TIMER0_H
#define _TIMER0_H

void Init_Timer0();

#endif
