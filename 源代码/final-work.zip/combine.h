#ifndef COMBINE_H
#define COMBINE_H
void start();
void myKeyEvent(int);

#endif