#ifndef _UART_H
#define _UART_H
extern char UartChar;
void UART_init();
void SendByte(unsigned char dat);
void SendStr(unsigned char *s);
#endif
