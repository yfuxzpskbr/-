#ifndef _MUSIC_H
#define _MUSIC_H
#include <reg51.h>
#include "music.h"
#include "delay.h"
#include <stdio.h>
#include <reg51.h>
sbit Speaker=P3^0;
extern unsigned char High,Low;
// ����Ƶ�ʱ� �߰�λ
extern unsigned char code FREQH[28];
// ����Ƶ�ʱ� �Ͱ�λ
extern unsigned char code FREQL[28];
extern unsigned char code MUSIC[16][16];
void playSong();
#endif
