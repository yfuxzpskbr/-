#include <reg51.h>
#include <stdio.h>
#include "music.h"
#include "timer0.h"
#include "delay.h"
int main(){
	Init_Timer0();
	while(1){
		playSong();
		delay(500);
	}
	return 0;
}